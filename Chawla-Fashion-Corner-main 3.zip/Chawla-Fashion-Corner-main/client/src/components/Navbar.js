import React, { useState } from 'react';
import styled from 'styled-components';
import { Link, NavLink } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

const Nav = styled.nav`
  background: #fff;
  box-shadow: 0 2px 8px rgba(80,0,80,0.06);
  padding: 1.2rem 3vw 1.2rem 3vw;
  display: flex;
  align-items: center;
  justify-content: space-between;
  position: sticky;
  top: 0;
  z-index: 100;
  border-radius: 0 0 2rem 2rem;
`;
const Logo = styled(Link)`
  font-size: 2.1rem;
  font-weight: 900;
  color: #7b2ff2;
  text-decoration: none;
  letter-spacing: 0.04em;
`;
const Hamburger = styled.button`
  display: none;
  background: none;
  border: none;
  font-size: 2rem;
  color: #7b2ff2;
  cursor: pointer;
  @media (max-width: 700px) {
    display: block;
  }
`;
const MobileMenu = styled.div`
  display: none;
  flex-direction: column;
  gap: 1.5rem;
  position: absolute;
  top: 100%;
  right: 0;
  background: #fff;
  box-shadow: 0 2px 8px rgba(80,0,80,0.10);
  border-radius: 0 0 1.5rem 1.5rem;
  padding: 1.5rem 2rem;
  z-index: 200;
  @media (max-width: 700px) {
    display: flex;
  }
`;
const NavLinks = styled.div`
  display: flex;
  gap: 2.2rem;
  align-items: center;
  @media (max-width: 700px) {
    display: none;
  }
`;
const StyledNavLink = styled(NavLink)`
  color: #18122B;
  text-decoration: none;
  font-size: 1.15rem;
  font-weight: 600;
  padding: 0.3rem 0.7rem 0.3rem 0.7rem;
  border-radius: 8px;
  position: relative;
  transition: color 0.2s;
  &.active, &:hover {
    color: #7b2ff2;
    text-decoration: none;
  }
`;
const CartIcon = styled(Link)`
  position: relative;
  color: #7b2ff2;
  font-size: 1.7rem;
  text-decoration: none;
  margin-left: 0.7rem;
`;

export default function Navbar() {
  const { cart } = useCart();
  const { user } = useAuth();
  const count = cart.reduce((sum, item) => sum + item.quantity, 0);
  const [menuOpen, setMenuOpen] = useState(false);
  return (
    <Nav>
      <Logo to="/">Chawla</Logo>
      <NavLinks>
        <StyledNavLink to="/">Home</StyledNavLink>
        <StyledNavLink to="/products">Products</StyledNavLink>
        <StyledNavLink to="/contact">Contact</StyledNavLink>
        {user ? (
          <span style={{fontWeight:600, color:'#7b2ff2', marginLeft:'1.2rem'}}>Hi, {user.name}</span>
        ) : (
          <StyledNavLink to="/login">Login</StyledNavLink>
        )}
        <CartIcon to="/cart" aria-label="Cart">
          🛒
          {count > 0 && <span style={{position:'absolute',top:'-8px',right:'-12px',background:'#f357a8',color:'#fff',borderRadius:'50%',fontSize:'0.9rem',padding:'2px 8px',fontWeight:'bold',boxShadow:'0 2px 8px rgba(243,87,168,0.15)'}}>{count}</span>}
        </CartIcon>
      </NavLinks>
      <Hamburger onClick={() => setMenuOpen(m => !m)} aria-label="Menu">
        {menuOpen ? '✖' : '☰'}
      </Hamburger>
      {menuOpen && (
        <MobileMenu>
          <StyledNavLink to="/" onClick={() => setMenuOpen(false)}>Home</StyledNavLink>
          <StyledNavLink to="/products" onClick={() => setMenuOpen(false)}>Products</StyledNavLink>
          <StyledNavLink to="/contact" onClick={() => setMenuOpen(false)}>Contact</StyledNavLink>
          {user ? (
            <span style={{fontWeight:600, color:'#7b2ff2', marginLeft:'1.2rem'}}>Hi, {user.name}</span>
          ) : (
            <StyledNavLink to="/login" onClick={() => setMenuOpen(false)}>Login</StyledNavLink>
          )}
          <CartIcon to="/cart" aria-label="Cart" onClick={() => setMenuOpen(false)}>
            🛒
            {count > 0 && <span style={{position:'absolute',top:'-8px',right:'-12px',background:'#f357a8',color:'#fff',borderRadius:'50%',fontSize:'0.9rem',padding:'2px 8px',fontWeight:'bold',boxShadow:'0 2px 8px rgba(243,87,168,0.15)'}}>{count}</span>}
          </CartIcon>
        </MobileMenu>
      )}
    </Nav>
  );
}