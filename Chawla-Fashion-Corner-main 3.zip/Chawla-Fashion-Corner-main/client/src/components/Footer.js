import React from 'react';
import styled from 'styled-components';

const FooterBar = styled.footer`
  background: #f8fafc;
  color: #18122B;
  text-align: center;
  padding: 2.5rem 1rem 1.5rem 1rem;
  margin-top: 3rem;
  border-top: 1px solid #e0e0e0;
`;
const Links = styled.div`
  margin-bottom: 1.2rem;
  a {
    color: #7b2ff2;
    margin: 0 1.2rem;
    text-decoration: none;
    font-weight: 500;
    font-size: 1.05rem;
    letter-spacing: 0.01em;
    transition: color 0.18s;
    &:hover { color: #f357a8; text-decoration: none; }
  }
`;
const Socials = styled.div`
  margin-bottom: 1.2rem;
  a {
    color: #7b2ff2;
    margin: 0 0.7rem;
    font-size: 1.3rem;
    transition: color 0.18s;
    &:hover { color: #f357a8; text-decoration: none; }
  }
`;
const Copyright = styled.div`
  font-size: 0.98rem;
  color: #555;
  letter-spacing: 0.01em;
`;

export default function Footer() {
  return (
    <FooterBar>
      <Links>
        <a href="/">Home</a>
        <a href="/products">Products</a>
        <a href="/contact">Contact</a>
      </Links>
      <Socials>
        <a href="https://www.instagram.com/" target="_blank" rel="noopener noreferrer" aria-label="Instagram">📸</a>
        <a href="https://www.facebook.com/" target="_blank" rel="noopener noreferrer" aria-label="Facebook">📘</a>
        <a href="mailto:info@chawlafashion.com" aria-label="Email">✉️</a>
      </Socials>
      <Copyright>
        &copy; {new Date().getFullYear()} Chawla Fashion Corner. All rights reserved.
      </Copyright>
    </FooterBar>
  );
}