import React, { useState } from 'react';
import styled from 'styled-components';
import { Link, useLocation } from 'react-router-dom';

const productsData = [
  { id: 1, name: 'Floral Kurti', price: 1299, image: '/1.jpg', category: 'kurtis', badge: 'New' },
  { id: 2, name: 'Trendy Co-ord Set', price: 1899, image: '/co-ord-sets.jpg', category: 'co-ord-sets', badge: 'Best Seller' },
  { id: 3, name: 'Summer Top', price: 799, image: '/girls-tops.jpg', category: 'tops' },
  { id: 4, name: 'Elegant Suit', price: 2199, image: '/stitched-suits.jpg', category: 'stitched-suits', badge: 'Sale' },
  { id: 5, name: 'Classic Kurti', price: 1199, image: '/1.jpg', category: 'kurtis' },
  { id: 6, name: 'Modern Top', price: 899, image: '/girls-tops.jpg', category: 'tops' },
  { id: 7, name: 'Pastel Co-ord', price: 2099, image: '/co-ord-sets.jpg', category: 'co-ord-sets', badge: 'New' },
  { id: 8, name: 'Designer Suit', price: 2499, image: '/stitched-suits.jpg', category: 'stitched-suits', badge: 'Limited' },
  { id: 9, name: 'Printed Kurti', price: 1399, image: '/1.jpg', category: 'kurtis', badge: 'Trending' },
  { id: 10, name: 'Chic Top', price: 999, image: '/girls-tops.jpg', category: 'tops', badge: 'Best Seller' },
  { id: 11, name: 'Elegant Co-ord', price: 1999, image: '/co-ord-sets.jpg', category: 'co-ord-sets' },
  { id: 12, name: 'Party Suit', price: 2799, image: '/stitched-suits.jpg', category: 'stitched-suits', badge: 'New' },
  { id: 13, name: 'Royal Kurti', price: 1599, image: '/1.jpg', category: 'kurtis', badge: 'Limited' },
  { id: 14, name: 'Urban Co-ord', price: 1899, image: '/co-ord-sets.jpg', category: 'co-ord-sets' },
  { id: 15, name: 'Festive Top', price: 1099, image: '/girls-tops.jpg', category: 'tops', badge: 'New' },
  { id: 16, name: 'Classic Suit', price: 2299, image: '/stitched-suits.jpg', category: 'stitched-suits' },
  { id: 17, name: 'Boho Kurti', price: 1499, image: '/1.jpg', category: 'kurtis', badge: 'Trending' },
  { id: 18, name: 'Minimal Co-ord', price: 1799, image: '/co-ord-sets.jpg', category: 'co-ord-sets' },
  { id: 19, name: 'Elegant Top', price: 899, image: '/girls-tops.jpg', category: 'tops' },
  { id: 20, name: 'Premium Suit', price: 2999, image: '/stitched-suits.jpg', category: 'stitched-suits', badge: 'Premium' },
  { id: 21, name: 'Vibrant Kurti', price: 1299, image: '/1.jpg', category: 'kurtis' },
  { id: 22, name: 'Street Co-ord', price: 1599, image: '/co-ord-sets.jpg', category: 'co-ord-sets', badge: 'Sale' },
  { id: 23, name: 'Trendy Top', price: 999, image: '/girls-tops.jpg', category: 'tops' },
  { id: 24, name: 'Designer Suit', price: 2599, image: '/stitched-suits.jpg', category: 'stitched-suits', badge: 'Best Seller' },
];

const categories = [
  { name: 'All', slug: '' },
  { name: 'Kurtis', slug: 'kurtis' },
  { name: 'Co-ord Sets', slug: 'co-ord-sets' },
  { name: 'Tops', slug: 'tops' },
  { name: 'Stitched Suits', slug: 'stitched-suits' },
];

const Wrapper = styled.div`
  max-width: 1300px;
  margin: 2.5rem auto;
  padding: 0 2vw;
  @media (max-width: 700px) {
    margin: 1.2rem auto;
    padding: 0 1vw;
  }
`;
const FilterBar = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 1.2rem;
  margin-bottom: 2.5rem;
  align-items: center;
  @media (max-width: 700px) {
    gap: 0.7rem;
    margin-bottom: 1.2rem;
  }
`;
const CategorySelect = styled.select`
  padding: 0.6rem 1.2rem;
  border-radius: 10px;
  border: 1px solid #e0e0e0;
  font-size: 1.05rem;
  @media (max-width: 700px) {
    font-size: 1rem;
    padding: 0.5rem 0.7rem;
  }
`;
const SearchInput = styled.input`
  padding: 0.6rem 1.2rem;
  border-radius: 10px;
  border: 1px solid #e0e0e0;
  flex: 1;
  font-size: 1.05rem;
  @media (max-width: 700px) {
    font-size: 1rem;
    padding: 0.5rem 0.7rem;
  }
`;
const Grid = styled.div`
  display: grid;
  grid-template-columns: repeat(4, 1fr);
  gap: 2.2rem;
  @media (max-width: 1100px) {
    grid-template-columns: repeat(3, 1fr);
  }
  @media (max-width: 800px) {
    grid-template-columns: repeat(2, 1fr);
  }
  @media (max-width: 500px) {
    grid-template-columns: 1fr;
    gap: 1.2rem;
  }
`;
const Card = styled.div`
  background: ${({ theme }) => theme.card};
  border-radius: 1.5rem;
  box-shadow: ${({ theme }) => theme.shadow};
  padding: 1.5rem 1.2rem 1.2rem 1.2rem;
  text-align: center;
  position: relative;
  transition: transform 0.18s, box-shadow 0.18s;
  display: flex;
  flex-direction: column;
  align-items: center;
  &:hover {
    transform: translateY(-8px) scale(1.03);
    box-shadow: 0 8px 32px rgba(123,47,242,0.13);
  }
  @media (max-width: 700px) {
    padding: 1rem 0.7rem 0.7rem 0.7rem;
  }
`;
const Badge = styled.span`
  position: absolute;
  top: 1.2rem;
  left: 1.2rem;
  background: #f357a8;
  color: #fff;
  font-size: 0.92rem;
  font-weight: 700;
  padding: 0.3rem 1rem;
  border-radius: 1rem;
  letter-spacing: 0.01em;
  box-shadow: 0 2px 8px rgba(123,47,242,0.10);
`;
const Img = styled.img`
  width: 100%;
  max-width: 170px;
  height: 170px;
  object-fit: cover;
  border-radius: 1.1rem;
  margin-bottom: 1.2rem;
  background: #f8fafc;
  box-shadow: 0 2px 8px rgba(123,47,242,0.06);
  @media (max-width: 700px) {
    max-width: 120px;
    height: 120px;
    margin-bottom: 0.7rem;
  }
`;
const Name = styled.h3`
  font-size: 1.13rem;
  color: ${({ theme }) => theme.primary};
  margin-bottom: 0.4rem;
  font-weight: 700;
`;
const Price = styled.p`
  color: ${({ theme }) => theme.secondary};
  font-weight: 700;
  font-size: 1.08rem;
  margin-bottom: 1.1rem;
`;
const CardLink = styled(Link)`
  text-decoration: none;
  color: inherit;
  display: block;
  &:hover {
    text-decoration: none;
  }
`;

function useQuery() {
  return new URLSearchParams(useLocation().search);
}

export default function Products() {
  const query = useQuery();
  const [category, setCategory] = useState(query.get('category') || '');
  const [search, setSearch] = useState('');

  const filtered = productsData.filter(prod =>
    (category === '' || prod.category === category) &&
    prod.name.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <Wrapper>
      <h1>Products</h1>
      <FilterBar>
        <CategorySelect value={category} onChange={e => setCategory(e.target.value)}>
          {categories.map(cat => (
            <option value={cat.slug} key={cat.slug}>{cat.name}</option>
          ))}
        </CategorySelect>
        <SearchInput
          type="text"
          placeholder="Search products..."
          value={search}
          onChange={e => setSearch(e.target.value)}
        />
      </FilterBar>
      <Grid>
        {filtered.map(prod => (
          <CardLink to={`/products/${prod.id}`} key={prod.id}>
            <Card>
              {prod.badge && <Badge>{prod.badge}</Badge>}
              <Img src={prod.image} alt={prod.name} />
              <Name>{prod.name}</Name>
              <Price>₹{prod.price}</Price>
            </Card>
          </CardLink>
        ))}
      </Grid>
    </Wrapper>
  );
} 