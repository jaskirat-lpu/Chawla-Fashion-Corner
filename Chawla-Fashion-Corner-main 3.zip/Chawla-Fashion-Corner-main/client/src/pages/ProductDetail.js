import React from 'react';
import styled from 'styled-components';
import { useParams, Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';

const productsData = [
  { id: 1, name: 'Floral Kurti', price: 1299, image: '/1.jpg', description: 'Beautiful floral kurti for all occasions.' },
  { id: 2, name: 'Trendy Co-ord Set', price: 1899, image: '/co-ord-sets.jpg', description: 'Trendy and comfortable co-ord set.' },
  { id: 3, name: 'Summer Top', price: 799, image: '/girls-tops.jpg', description: 'Light and breezy summer top.' },
  { id: 4, name: 'Elegant Suit', price: 2199, image: '/stitched-suits.jpg', description: 'Elegant stitched suit for parties.' },
];

const Wrapper = styled.div`
  max-width: 900px;
  margin: 2rem auto;
  padding: 0 1rem;
`;
const Flex = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 2rem;
`;
const Img = styled.img`
  width: 100%;
  max-width: 320px;
  border-radius: 16px;
`;
const Info = styled.div`
  flex: 1;
`;
const Name = styled.h1`
  color: #512e5f;
`;
const Price = styled.p`
  color: #6c3483;
  font-size: 1.5rem;
  font-weight: bold;
`;
const Desc = styled.p`
  color: #333;
  margin: 1rem 0;
`;
const AddBtn = styled.button`
  background: #6c3483;
  color: #fff;
  padding: 0.7rem 2rem;
  border: none;
  border-radius: 30px;
  font-size: 1.1rem;
  cursor: pointer;
  margin-top: 1rem;
  transition: background 0.2s;
  &:hover { background: #512e5f; }
`;

export default function ProductDetail() {
  const { id } = useParams();
  const { dispatch } = useCart();
  const product = productsData.find(p => p.id === Number(id));

  if (!product) return <Wrapper>Product not found.</Wrapper>;

  const handleAdd = () => {
    dispatch({ type: 'ADD_TO_CART', payload: { ...product, quantity: 1 } });
    alert('Added to cart!');
  };

  return (
    <Wrapper>
      <Flex>
        <Img src={product.image} alt={product.name} />
        <Info>
          <Name>{product.name}</Name>
          <Price>₹{product.price}</Price>
          <Desc>{product.description}</Desc>
          <AddBtn onClick={handleAdd}>Add to Cart</AddBtn>
        </Info>
      </Flex>
      <h2 style={{ marginTop: '3rem', color: '#512e5f' }}>Related Products</h2>
      <div style={{ display: 'flex', gap: '1.5rem', flexWrap: 'wrap' }}>
        {productsData.filter(p => p.id !== product.id).slice(0, 3).map(p => (
          <Link to={`/products/${p.id}`} key={p.id} style={{ textDecoration: 'none', color: '#6c3483' }}>
            <div style={{ background: '#fff', borderRadius: 12, boxShadow: '0 2px 8px rgba(80,0,80,0.08)', padding: 16, width: 180, textAlign: 'center' }}>
              <img src={p.image} alt={p.name} style={{ width: '100%', borderRadius: 8, marginBottom: 8 }} />
              <div style={{ fontWeight: 600 }}>{p.name}</div>
              <div style={{ color: '#6c3483' }}>₹{p.price}</div>
            </div>
          </Link>
        ))}
      </div>
    </Wrapper>
  );
} 