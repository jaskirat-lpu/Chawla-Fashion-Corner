import React from 'react';
import styled from 'styled-components';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';

const Wrapper = styled.div`
  max-width: 900px;
  margin: 2rem auto;
  padding: 0 1rem;
`;
const Table = styled.table`
  width: 100%;
  border-collapse: collapse;
  margin-bottom: 2rem;
`;
const Th = styled.th`
  text-align: left;
  padding: 0.7rem;
  background: #f4ecf7;
  color: #6c3483;
`;
const Td = styled.td`
  padding: 0.7rem;
  border-bottom: 1px solid #eee;
`;
const Img = styled.img`
  width: 60px;
  border-radius: 8px;
`;
const RemoveBtn = styled.button`
  background: #e74c3c;
  color: #fff;
  border: none;
  border-radius: 8px;
  padding: 0.4rem 1rem;
  cursor: pointer;
  font-size: 0.95rem;
  transition: background 0.2s;
  &:hover { background: #c0392b; }
`;
const CheckoutBtn = styled.button`
  background: #6c3483;
  color: #fff;
  border: none;
  border-radius: 30px;
  padding: 0.8rem 2rem;
  font-size: 1.1rem;
  cursor: pointer;
  transition: background 0.2s;
  &:hover { background: #512e5f; }
`;

export default function Cart() {
  const { cart, dispatch } = useCart();
  const navigate = useNavigate();
  const { user } = useAuth();

  const handleRemove = id => {
    dispatch({ type: 'REMOVE_FROM_CART', payload: id });
  };
  const handleQuantity = (id, quantity) => {
    if (quantity < 1) return;
    dispatch({ type: 'UPDATE_QUANTITY', payload: { id, quantity } });
  };
  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const handleCheckout = () => {
    if (!user) {
      navigate('/login?redirect=/checkout');
    } else {
      navigate('/checkout');
    }
  };

  return (
    <Wrapper>
      <h1>Your Cart</h1>
      {cart.length === 0 ? (
        <p>Your cart is empty. <Link to="/products">Shop now</Link></p>
      ) : (
        <>
          <Table>
            <thead>
              <tr>
                <Th>Product</Th>
                <Th>Price</Th>
                <Th>Quantity</Th>
                <Th>Subtotal</Th>
                <Th></Th>
              </tr>
            </thead>
            <tbody>
              {cart.map(item => (
                <tr key={item.id}>
                  <Td><Img src={item.image} alt={item.name} /> {item.name}</Td>
                  <Td>₹{item.price}</Td>
                  <Td>
                    <input
                      type="number"
                      min="1"
                      value={item.quantity}
                      style={{ width: 50, padding: 4, borderRadius: 6, border: '1px solid #ccc' }}
                      onChange={e => handleQuantity(item.id, Number(e.target.value))}
                    />
                  </Td>
                  <Td>₹{item.price * item.quantity}</Td>
                  <Td><RemoveBtn onClick={() => handleRemove(item.id)}>Remove</RemoveBtn></Td>
                </tr>
              ))}
            </tbody>
          </Table>
          <h2>Total: ₹{total}</h2>
          <CheckoutBtn onClick={handleCheckout}>Proceed to Checkout</CheckoutBtn>
        </>
      )}
    </Wrapper>
  );
} 