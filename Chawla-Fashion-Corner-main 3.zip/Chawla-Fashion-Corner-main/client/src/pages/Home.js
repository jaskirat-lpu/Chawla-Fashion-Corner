import React from 'react';
import styled from 'styled-components';
import { Link } from 'react-router-dom';

const Hero = styled.section`
  background: linear-gradient(120deg, #f8fafc 60%, #e0c3fc 100%);
  padding: 5rem 2vw 3rem 2vw;
  text-align: center;
  border-radius: 0 0 2.5rem 2.5rem;
  box-shadow: 0 4px 24px rgba(123,47,242,0.07);
  @media (max-width: 700px) {
    padding: 2.5rem 2vw 1.5rem 2vw;
  }
  @media (max-width: 500px) {
    padding: 1.2rem 1vw 0.7rem 1vw;
  }
`;
const Title = styled.h1`
  font-size: 2.7rem;
  margin-bottom: 1.2rem;
  color: #7b2ff2;
  font-weight: 900;
  letter-spacing: 0.03em;
  @media (max-width: 700px) {
    font-size: 1.7rem;
  }
  @media (max-width: 500px) {
    font-size: 1.2rem;
  }
`;
const Subtitle = styled.p`
  font-size: 1.25rem;
  color: #18122B;
  margin-bottom: 2.2rem;
  font-weight: 500;
  @media (max-width: 700px) {
    font-size: 1rem;
  }
  @media (max-width: 500px) {
    font-size: 0.95rem;
  }
`;
const ShopButton = styled(Link)`
  background: #7b2ff2;
  color: #fff;
  padding: 1rem 2.5rem;
  border-radius: 2rem;
  font-size: 1.15rem;
  text-decoration: none;
  font-weight: 700;
  letter-spacing: 0.01em;
  box-shadow: 0 2px 8px rgba(123,47,242,0.10);
  transition: background 0.18s, color 0.18s;
  &:hover { background: #f357a8; color: #fff; text-decoration: none; }
  @media (max-width: 700px) {
    font-size: 1rem;
    padding: 0.7rem 1.5rem;
  }
  @media (max-width: 500px) {
    font-size: 0.95rem;
    padding: 0.6rem 1rem;
  }
`;
const Section = styled.section`
  padding: 2.5rem 2vw 0 2vw;
  @media (max-width: 700px) {
    padding: 1.2rem 2vw 0 2vw;
  }
  @media (max-width: 500px) {
    padding: 0.7rem 1vw 0 1vw;
  }
`;
const SectionTitle = styled.h2`
  font-size: 2rem;
  color: #7b2ff2;
  margin-bottom: 2rem;
  font-weight: 800;
  @media (max-width: 700px) {
    font-size: 1.2rem;
    margin-bottom: 1rem;
  }
  @media (max-width: 500px) {
    font-size: 1rem;
    margin-bottom: 0.7rem;
  }
`;
const Categories = styled.div`
  display: flex;
  flex-wrap: wrap;
  gap: 1.5rem;
  justify-content: center;
  @media (max-width: 700px) {
    gap: 0.7rem;
  }
`;
const CategoryCard = styled(Link)`
  background: #fff;
  border-radius: 1.2rem;
  box-shadow: 0 2px 8px rgba(123,47,242,0.08);
  padding: 1.5rem 2.2rem;
  min-width: 180px;
  text-align: center;
  color: #7b2ff2;
  font-weight: 700;
  text-decoration: none;
  font-size: 1.13rem;
  letter-spacing: 0.01em;
  transition: box-shadow 0.18s, background 0.18s, color 0.18s;
  &:hover { box-shadow: 0 4px 16px rgba(123,47,242,0.16); background: #f4ecf7; color: #f357a8; text-decoration: none; }
  @media (max-width: 700px) {
    min-width: 120px;
    font-size: 1rem;
    padding: 1rem 1.2rem;
  }
  @media (max-width: 500px) {
    min-width: 90px;
    font-size: 0.95rem;
    padding: 0.7rem 0.7rem;
  }
`;
const FeaturedGrid = styled.div`
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(260px, 1fr));
  gap: 2.2rem;
  @media (max-width: 700px) {
    grid-template-columns: 1fr;
    gap: 1.2rem;
  }
`;
const Card = styled.div`
  background: ${({ theme }) => theme.card};
  border-radius: 1.5rem;
  box-shadow: ${({ theme }) => theme.shadow};
  padding: 1.5rem 1.2rem 1.2rem 1.2rem;
  text-align: center;
  position: relative;
  transition: transform 0.18s, box-shadow 0.18s;
  display: flex;
  flex-direction: column;
  align-items: center;
  &:hover {
    transform: translateY(-8px) scale(1.03);
    box-shadow: 0 8px 32px rgba(123,47,242,0.13);
  }
  @media (max-width: 700px) {
    padding: 1rem 0.7rem 0.7rem 0.7rem;
  }
`;
const Badge = styled.span`
  position: absolute;
  top: 1.2rem;
  left: 1.2rem;
  background: #f357a8;
  color: #fff;
  font-size: 0.92rem;
  font-weight: 700;
  padding: 0.3rem 1rem;
  border-radius: 1rem;
  letter-spacing: 0.01em;
  box-shadow: 0 2px 8px rgba(123,47,242,0.10);
`;
const Img = styled.img`
  width: 100%;
  max-width: 170px;
  height: 170px;
  object-fit: cover;
  border-radius: 1.1rem;
  margin-bottom: 1.2rem;
  background: #f8fafc;
  box-shadow: 0 2px 8px rgba(123,47,242,0.06);
  @media (max-width: 700px) {
    max-width: 120px;
    height: 120px;
    margin-bottom: 0.7rem;
  }
`;
const Name = styled.h3`
  font-size: 1.13rem;
  color: ${({ theme }) => theme.primary};
  margin-bottom: 0.4rem;
  font-weight: 700;
`;
const Price = styled.p`
  color: ${({ theme }) => theme.secondary};
  font-weight: 700;
  font-size: 1.08rem;
  margin-bottom: 1.1rem;
`;
const ViewBtn = styled(Link)`
  background: #7b2ff2;
  color: #fff;
  padding: 0.6rem 1.5rem;
  border-radius: 1.2rem;
  font-size: 1.05rem;
  text-decoration: none;
  font-weight: 600;
  letter-spacing: 0.01em;
  margin-top: auto;
  transition: background 0.18s, color 0.18s;
  box-shadow: 0 2px 8px rgba(123,47,242,0.08);
  &:hover {
    background: #f357a8;
    color: #fff;
    text-decoration: none;
  }
`;

const categories = [
  { name: 'Kurtis', slug: 'kurtis' },
  { name: 'Co-ord Sets', slug: 'co-ord-sets' },
  { name: 'Tops', slug: 'tops' },
  { name: 'Stitched Suits', slug: 'stitched-suits' },
];

const featured = [
  { id: 1, name: 'Floral Kurti', price: 1299, image: '/1.jpg', badge: 'New' },
  { id: 2, name: 'Trendy Co-ord Set', price: 1899, image: '/co-ord-sets.jpg', badge: 'Best Seller' },
  { id: 3, name: 'Summer Top', price: 799, image: '/girls-tops.jpg' },
  { id: 4, name: 'Elegant Suit', price: 2199, image: '/stitched-suits.jpg', badge: 'Sale' },
];

export default function Home() {
  return (
    <>
      <Hero>
        <Title>Chawla Fashion Corner</Title>
        <Subtitle>Discover the latest trends in ethnic and western wear for girls. Shop our exclusive collection now!</Subtitle>
        <ShopButton to="/products">Shop Now</ShopButton>
      </Hero>
      <Section>
        <SectionTitle>Categories</SectionTitle>
        <Categories>
          {categories.map(cat => (
            <CategoryCard to={`/products?category=${cat.slug}`} key={cat.slug}>{cat.name}</CategoryCard>
          ))}
        </Categories>
      </Section>
      <Section>
        <SectionTitle>Featured Products</SectionTitle>
        <FeaturedGrid>
          {featured.map(prod => (
            <Card key={prod.id}>
              {prod.badge && <Badge>{prod.badge}</Badge>}
              <Img src={prod.image} alt={prod.name} />
              <Name>{prod.name}</Name>
              <Price>₹{prod.price}</Price>
              <ViewBtn to={`/products/${prod.id}`}>View</ViewBtn>
            </Card>
          ))}
        </FeaturedGrid>
      </Section>
    </>
  );
} 