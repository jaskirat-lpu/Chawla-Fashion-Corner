import React, { createContext, useContext, useState, useCallback } from 'react';
import styled, { keyframes } from 'styled-components';

const ToastContext = createContext();

const fadeIn = keyframes`
  from { opacity: 0; transform: translateY(30px); }
  to { opacity: 1; transform: translateY(0); }
`;

const ToastContainer = styled.div`
  position: fixed;
  bottom: 2rem;
  right: 2rem;
  z-index: 9999;
`;
const ToastMsg = styled.div`
  background: ${({ type }) =>
    type === 'success' ? '#27ae60' : type === 'error' ? '#e74c3c' : '#7b2ff2'};
  color: #fff;
  padding: 1rem 2rem;
  border-radius: 12px;
  margin-bottom: 1rem;
  min-width: 220px;
  box-shadow: 0 2px 8px rgba(80,0,80,0.18);
  font-weight: 500;
  animation: ${fadeIn} 0.3s;
`;

export function ToastProvider({ children }) {
  const [toasts, setToasts] = useState([]);

  const showToast = useCallback((msg, type = 'info') => {
    const id = Date.now();
    setToasts(ts => [...ts, { id, msg, type }]);
    setTimeout(() => setToasts(ts => ts.filter(t => t.id !== id)), 3000);
  }, []);

  return (
    <ToastContext.Provider value={{ showToast }}>
      {children}
      <ToastContainer>
        {toasts.map(t => (
          <ToastMsg key={t.id} type={t.type}>{t.msg}</ToastMsg>
        ))}
      </ToastContainer>
    </ToastContext.Provider>
  );
}

export function useToast() {
  return useContext(ToastContext);
} 