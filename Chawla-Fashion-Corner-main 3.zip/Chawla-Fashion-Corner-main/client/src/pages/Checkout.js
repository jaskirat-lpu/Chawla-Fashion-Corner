import React, { useState } from 'react';
import styled from 'styled-components';
import { useCart } from '../context/CartContext';

const Wrapper = styled.div`
  max-width: 700px;
  margin: 2rem auto;
  padding: 0 1rem;
`;
const Form = styled.form`
  background: #fff;
  border-radius: 16px;
  box-shadow: 0 2px 8px rgba(80,0,80,0.08);
  padding: 2rem;
  margin-bottom: 2rem;
`;
const Label = styled.label`
  display: block;
  margin-bottom: 0.5rem;
  color: #6c3483;
`;
const Input = styled.input`
  width: 100%;
  padding: 0.7rem;
  border-radius: 8px;
  border: 1px solid #ccc;
  margin-bottom: 1.2rem;
`;
const OrderSummary = styled.div`
  background: #f4ecf7;
  border-radius: 12px;
  padding: 1.5rem;
  margin-bottom: 2rem;
`;
const PlaceBtn = styled.button`
  background: #6c3483;
  color: #fff;
  border: none;
  border-radius: 30px;
  padding: 0.8rem 2rem;
  font-size: 1.1rem;
  cursor: pointer;
  transition: background 0.2s;
  &:hover { background: #512e5f; }
`;
const OrderList = styled.div`
  background: #fff;
  border-radius: 12px;
  box-shadow: 0 2px 8px rgba(80,0,80,0.08);
  padding: 1.5rem;
  margin-bottom: 2rem;
`;
const OrderItem = styled.div`
  display: flex;
  justify-content: space-between;
  align-items: center;
  padding: 0.7rem 0;
  border-bottom: 1px solid #eee;
  font-size: 1.05rem;
  &:last-child { border-bottom: none; }
`;
const OrderTotal = styled.div`
  text-align: right;
  font-weight: 700;
  font-size: 1.1rem;
  margin-top: 1rem;
`;

export default function Checkout() {
  const { cart, dispatch } = useCart();
  const [form, setForm] = useState({ name: '', email: '', address: '', phone: '' });
  const [submitted, setSubmitted] = useState(false);
  const [order, setOrder] = useState([]);

  const total = cart.reduce((sum, item) => sum + item.price * item.quantity, 0);

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = e => {
    e.preventDefault();
    if (!form.name || !form.email || !form.address || !form.phone) {
      alert('Please fill all fields');
      return;
    }
    setOrder(cart);
    setSubmitted(true);
    dispatch({ type: 'CLEAR_CART' });
  };

  if (submitted) {
    return (
      <Wrapper>
        <h1>Thank you for your order!</h1>
        <p>We have received your order and will contact you soon.</p>
        <OrderList>
          <h2 style={{marginBottom: '1rem'}}>Your Order</h2>
          {order.map(item => (
            <OrderItem key={item.id}>
              <span>{item.name} x {item.quantity}</span>
              <span>₹{item.price * item.quantity}</span>
            </OrderItem>
          ))}
          <OrderTotal>Total: ₹{order.reduce((sum, item) => sum + item.price * item.quantity, 0)}</OrderTotal>
        </OrderList>
      </Wrapper>
    );
  }

  return (
    <Wrapper>
      <h1>Checkout</h1>
      <Form onSubmit={handleSubmit}>
        <Label>Name</Label>
        <Input name="name" value={form.name} onChange={handleChange} required />
        <Label>Email</Label>
        <Input name="email" type="email" value={form.email} onChange={handleChange} required />
        <Label>Address</Label>
        <Input name="address" value={form.address} onChange={handleChange} required />
        <Label>Phone</Label>
        <Input name="phone" value={form.phone} onChange={handleChange} required />
        <PlaceBtn type="submit">Place Order</PlaceBtn>
      </Form>
      <OrderSummary>
        <h2>Order Summary</h2>
        {cart.map(item => (
          <div key={item.id} style={{ marginBottom: 8 }}>
            {item.name} x {item.quantity} = ₹{item.price * item.quantity}
          </div>
        ))}
        <div style={{ fontWeight: 600, marginTop: 12 }}>Total: ₹{total}</div>
      </OrderSummary>
    </Wrapper>
  );
} 