import React, { useState } from 'react';
import styled from 'styled-components';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import api from '../utils/api';
import { useToast } from '../components/Toast';

const Wrapper = styled.div`
  max-width: 400px;
  margin: 3rem auto;
  padding: 2.5rem 2rem 2rem 2rem;
  background: #fff;
  border-radius: 16px;
  box-shadow: 0 2px 8px rgba(80,0,80,0.08);
`;
const Title = styled.h1`
  color: #7b2ff2;
  font-size: 2rem;
  margin-bottom: 1.5rem;
  text-align: center;
`;
const Label = styled.label`
  display: block;
  margin-bottom: 0.5rem;
  color: #18122B;
  font-weight: 500;
`;
const Input = styled.input`
  width: 100%;
  padding: 0.7rem;
  border-radius: 8px;
  border: 1px solid #e0e0e0;
  margin-bottom: 1.2rem;
  font-size: 1rem;
`;
const Button = styled.button`
  width: 100%;
  background: #7b2ff2;
  color: #fff;
  border: none;
  border-radius: 1.2rem;
  padding: 0.8rem 0;
  font-size: 1.1rem;
  font-weight: 600;
  margin-top: 0.5rem;
  transition: background 0.18s;
  box-shadow: 0 2px 8px rgba(123,47,242,0.08);
  cursor: pointer;
  &:hover { background: #f357a8; }
`;
const BottomText = styled.div`
  text-align: center;
  margin-top: 1.2rem;
  font-size: 1rem;
`;
const Error = styled.div`
  color: #e74c3c;
  margin-bottom: 1rem;
  text-align: center;
`;

export default function Login() {
  const [form, setForm] = useState({ phone: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();
  const { login } = useAuth();
  const { showToast } = useToast();

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    if (!form.phone || !form.password) {
      setError('Please fill in all fields.');
      showToast('Please fill in all fields.', 'error');
      return;
    }
    if (!/^\d{10}$/.test(form.phone)) {
      setError('Please enter a valid 10-digit phone number.');
      showToast('Please enter a valid 10-digit phone number.', 'error');
      return;
    }
    setLoading(true);
    try {
      const res = await api.post('/api/login', form);
      login(res.data.user, res.data.token);
      api.defaults.headers.common['Authorization'] = `Bearer ${res.data.token}`;
      setError('');
      showToast('Login successful!', 'success');
      const params = new URLSearchParams(location.search);
      const redirect = params.get('redirect');
      navigate(redirect || '/');
    } catch (err) {
      const msg = err.response?.data?.error || 'Login failed';
      setError(msg);
      showToast(msg, 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Wrapper>
      <Title>Login</Title>
      {error && <Error>{error}</Error>}
      <form onSubmit={handleSubmit}>
        <Label>Phone Number</Label>
        <Input name="phone" type="tel" value={form.phone} onChange={handleChange} required maxLength={10} pattern="\d{10}" placeholder="Enter 10-digit number" />
        <Label>Password</Label>
        <Input name="password" type="password" value={form.password} onChange={handleChange} required />
        <Button type="submit" disabled={loading}>{loading ? 'Logging in...' : 'Login'}</Button>
      </form>
      <BottomText>
        Don't have an account? <Link to="/signup">Sign up</Link>
      </BottomText>
    </Wrapper>
  );
} 