import React, { useState } from 'react';
import styled from 'styled-components';

const Wrapper = styled.div`
  max-width: 600px;
  margin: 2rem auto;
  padding: 0 1rem;
`;
const Form = styled.form`
  background: #fff;
  border-radius: 16px;
  box-shadow: 0 2px 8px rgba(80,0,80,0.08);
  padding: 2rem;
`;
const Label = styled.label`
  display: block;
  margin-bottom: 0.5rem;
  color: #6c3483;
`;
const Input = styled.input`
  width: 100%;
  padding: 0.7rem;
  border-radius: 8px;
  border: 1px solid #ccc;
  margin-bottom: 1.2rem;
`;
const Textarea = styled.textarea`
  width: 100%;
  padding: 0.7rem;
  border-radius: 8px;
  border: 1px solid #ccc;
  margin-bottom: 1.2rem;
  min-height: 100px;
`;
const SubmitBtn = styled.button`
  background: #6c3483;
  color: #fff;
  border: none;
  border-radius: 30px;
  padding: 0.8rem 2rem;
  font-size: 1.1rem;
  cursor: pointer;
  transition: background 0.2s;
  &:hover { background: #512e5f; }
`;

export default function Contact() {
  const [form, setForm] = useState({ name: '', email: '', message: '' });
  const [submitted, setSubmitted] = useState(false);

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = e => {
    e.preventDefault();
    if (!form.name || !form.email || !form.message) {
      alert('Please fill all fields');
      return;
    }
    setSubmitted(true);
  };

  if (submitted) {
    return (
      <Wrapper>
        <h1>Thank you!</h1>
        <p>Your message has been sent. We will get back to you soon.</p>
      </Wrapper>
    );
  }

  return (
    <Wrapper>
      <h1>Contact Us</h1>
      <Form onSubmit={handleSubmit}>
        <Label>Name</Label>
        <Input name="name" value={form.name} onChange={handleChange} required />
        <Label>Email</Label>
        <Input name="email" type="email" value={form.email} onChange={handleChange} required />
        <Label>Message</Label>
        <Textarea name="message" value={form.message} onChange={handleChange} required />
        <SubmitBtn type="submit">Send</SubmitBtn>
      </Form>
    </Wrapper>
  );
} 