import React, { useState } from 'react';
import styled from 'styled-components';
import { Link, useNavigate } from 'react-router-dom';
import api from '../utils/api';
import { useToast } from '../components/Toast';

const Wrapper = styled.div`
  max-width: 400px;
  margin: 3rem auto;
  padding: 2.5rem 2rem 2rem 2rem;
  background: #fff;
  border-radius: 16px;
  box-shadow: 0 2px 8px rgba(80,0,80,0.08);
`;
const Title = styled.h1`
  color: #7b2ff2;
  font-size: 2rem;
  margin-bottom: 1.5rem;
  text-align: center;
`;
const Label = styled.label`
  display: block;
  margin-bottom: 0.5rem;
  color: #18122B;
  font-weight: 500;
`;
const Input = styled.input`
  width: 100%;
  padding: 0.7rem;
  border-radius: 8px;
  border: 1px solid #e0e0e0;
  margin-bottom: 1.2rem;
  font-size: 1rem;
`;
const Button = styled.button`
  width: 100%;
  background: #7b2ff2;
  color: #fff;
  border: none;
  border-radius: 1.2rem;
  padding: 0.8rem 0;
  font-size: 1.1rem;
  font-weight: 600;
  margin-top: 0.5rem;
  transition: background 0.18s;
  box-shadow: 0 2px 8px rgba(123,47,242,0.08);
  cursor: pointer;
  &:hover { background: #f357a8; }
`;
const BottomText = styled.div`
  text-align: center;
  margin-top: 1.2rem;
  font-size: 1rem;
`;
const Error = styled.div`
  color: #e74c3c;
  margin-bottom: 1rem;
  text-align: center;
`;

export default function Signup() {
  const [form, setForm] = useState({ name: '', phone: '', email: '', password: '' });
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();
  const { showToast } = useToast();

  const handleChange = e => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = async e => {
    e.preventDefault();
    if (!form.name || !form.phone || !form.email || !form.password) {
      setError('Please fill in all fields.');
      showToast('Please fill in all fields.', 'error');
      return;
    }
    if (!/^\d{10}$/.test(form.phone)) {
      setError('Please enter a valid 10-digit phone number.');
      showToast('Please enter a valid 10-digit phone number.', 'error');
      return;
    }
    setLoading(true);
    try {
      await api.post('/api/signup', form);
      setError('');
      showToast('Signup successful! Please login.', 'success');
      navigate('/login');
    } catch (err) {
      const msg = err.response?.data?.error || 'Signup failed';
      setError(msg);
      showToast(msg, 'error');
    } finally {
      setLoading(false);
    }
  };

  return (
    <Wrapper>
      <Title>Sign Up</Title>
      {error && <Error>{error}</Error>}
      <form onSubmit={handleSubmit}>
        <Label>Name</Label>
        <Input name="name" value={form.name} onChange={handleChange} required />
        <Label>Phone Number</Label>
        <Input name="phone" type="tel" value={form.phone} onChange={handleChange} required maxLength={10} pattern="\d{10}" placeholder="Enter 10-digit number" />
        <Label>Email</Label>
        <Input name="email" type="email" value={form.email} onChange={handleChange} required />
        <Label>Password</Label>
        <Input name="password" type="password" value={form.password} onChange={handleChange} required />
        <Button type="submit" disabled={loading}>{loading ? 'Signing up...' : 'Sign Up'}</Button>
      </form>
      <BottomText>
        Already have an account? <Link to="/login">Login</Link>
      </BottomText>
    </Wrapper>
  );
} 