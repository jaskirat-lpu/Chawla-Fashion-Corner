export const lightTheme = {
  background: '#f8fafc',
  card: '#fff',
  primary: '#7b2ff2',
  secondary: '#f357a8',
  accent: '#7b2ff2',
  text: '#18122B',
  textSecondary: '#555',
  border: '#e0e0e0',
  shadow: '0 2px 8px rgba(80,0,80,0.08)',
  button: '#7b2ff2',
  buttonText: '#fff',
  buttonHover: '#f357a8',
};

export const darkTheme = {
  background: '#18122B',
  card: '#231942',
  primary: '#e0c3fc',
  secondary: '#f357a8',
  accent: '#7b2ff2',
  text: '#f8fafc',
  textSecondary: '#b8b8d1',
  border: '#2d2d44',
  shadow: '0 2px 8px rgba(80,0,80,0.18)',
  button: '#7b2ff2',
  buttonText: '#fff',
  buttonHover: '#f357a8',
};

export const spacing = {
  xs: '0.5rem',
  sm: '1.25rem',
  md: '2.5rem',
  lg: '4rem',
}; 